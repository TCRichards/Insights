Most of the icons used by the PsychoPy app come from the Crystal icon set by Everaldo Coelho which are distributed under the LGPL

http://www.softicons.com/system-icons/crystal-project-icons-by-everaldo-coelho

globe is browser from the Intrigue icon set

Clouds from https://www.flaticon.com/authors/smashicons licensed under CC-BY 3.0

user is based on im-user.png from the Oxygen set 
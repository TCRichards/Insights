#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Coder is the python IDE for PsychoPy
"""

from __future__ import absolute_import, print_function
from .coder import *  # pylint: disable=W0401

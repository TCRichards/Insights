This demo shows you how to use the new, simpler rating scales called Sliders.

Unlike the previous RatingScale component the Slider doesn't have controls
like an accept button (although you could add that with your own objects)
but it does support:
  - a much simpler interface
  - vertical or horizontal scales (set the size to be portrait or landscape)
  - customization by styles or by code

Stroop - with ioHub Keyboard Device via Custom Code Component.
------------------------------------------------------------------

This is a lot like the original Stroop task provided in the PsychoPy demos. 

We just added a Code Component to add access to ioHub Keyboard events, for keydown time info.

Please edit the iohub_config.yaml file to set the display device parameters so they are valid for your setup.


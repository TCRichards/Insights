By Daniel Riggs, daniel.riggs1@gmail.com, September 2016

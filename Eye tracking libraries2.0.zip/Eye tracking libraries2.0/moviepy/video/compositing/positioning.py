"""
This module provides classes that make positioning easy
"""

# class ClipPosition:
